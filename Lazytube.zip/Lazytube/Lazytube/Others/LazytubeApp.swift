//
//  LazytubeApp.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 17.11.2023.
//

import SwiftUI

@main
struct LazytubeApp: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView()
                .accentColor(.teal)
        }
    }
}
