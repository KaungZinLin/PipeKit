//
//  Constants.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 18.11.2023.
//

import Foundation

class Constants {
    static var OPEN_WEATHER_API_KEY = "cc4fdee8f310fe3fba972c2be52bcac5"
    static var YOUTUBE_DATA_V3_API_KEY = "AIzaSyDq0eVTnbIZ98uq5Evpg2tC73vgf4Ifr4o"
    static var OPEN_AI_API_KEY = ""
    static var DEVELOPER_EMAIL = "kaung.zl2011@gmail.com"
}
