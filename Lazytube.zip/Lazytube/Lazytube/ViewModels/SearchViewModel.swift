//
//  SearchViewModel.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 22.11.2023.
//

import Foundation

class SearchViewModel: ObservableObject {
    @Published var videos: [YouTubeVideo] = []
    
    func searchVideos(query: String) {
        guard let encodedQuery = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else {
            return
        }
        
        let apiKey = Constants.YOUTUBE_DATA_V3_API_KEY
        let baseURL = "https://www.googleapis.com/youtube/v3/"
        let urlString = "\(baseURL)search?part=snippet&maxResults=30&q=\(encodedQuery)&key=\(apiKey)"
        
        guard let url = URL(string: urlString) else {
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                return
            }
            
            do {
                let decoder = JSONDecoder()
                let response = try decoder.decode(SearchResponse.self, from: data)
                DispatchQueue.main.async {
                    self.videos = response.items
                }
            } catch {
                print("Error decoding JSON: \(error)")
            }
        }.resume()
    }
}


