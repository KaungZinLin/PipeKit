//
//  ChannelViewModel.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 21.11.2023.
//

import Foundation

class ChannelViewModel: ObservableObject {
    let urlString = "https://www.youtube.com/channel/"
}
