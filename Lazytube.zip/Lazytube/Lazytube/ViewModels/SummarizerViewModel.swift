//
//  SummarizerViewModel.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 19.11.2023.
//

import Foundation

class SummarizerViewModel: ObservableObject {
    
}
