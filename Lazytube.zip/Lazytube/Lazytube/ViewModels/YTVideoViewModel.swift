//
//  YTVideoViewModel.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 19.11.2023.
//

import Foundation
import Combine
import AVFoundation

class YTVideoViewModel: ObservableObject {
    static let shared = YTVideoViewModel()
    let apiKey = Constants.YOUTUBE_DATA_V3_API_KEY
    let urlString = "https://www.youtube.com/watch?v="
    
    func fetchVideoInfo(videoId: String, completion: @escaping (Item?) -> Void) {
        let urlString = "https://www.googleapis.com/youtube/v3/videos?id=\(videoId)&key=\(apiKey)&part=snippet,statistics"
        
        if let url = URL(string: urlString) {
            URLSession.shared.dataTask(with: url) { data, response, error in
                if let data = data {
                    do {
                        let decoder = JSONDecoder()
                        let videoInfo = try decoder.decode(VideoInfo.self, from: data)
                        if let item = videoInfo.items.first {
                            completion(item)
                        } else {
                            completion(nil)
                        }
                    } catch {
                        print("Error decoding JSON: \(error)")
                        completion(nil)
                    }
                } else {
                    completion(nil)
                }
            }.resume()
        }
    }
    
    func formatDate(_ dateStr: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEEE, MMM d, yyyy"
        
        if let date = dateFormatter.date(from: dateStr) {
            dateFormatter.dateStyle = .medium
            dateFormatter.timeStyle = .medium
            return dateFormatter.string(from: date)
        } else {
            return "Invalid Date"
        }
    }
    
    func textToSpeech(inputText: String) {
        let speechSynthesizer = AVSpeechSynthesizer()
        let utterance = AVSpeechUtterance(string: inputText)
        
        utterance.pitchMultiplier = 1.0
        utterance.rate = 0.5
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
         
        speechSynthesizer.speak(utterance)
    }
}

