//
//  DownloadsViewMode.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 20.11.2023.
//

import Foundation
import UIKit
import SwiftUI

class DownloadsViewModel: ObservableObject {
    @Published var downloadsContent: [URL] = []

    func fetchDownloadsContents() {
        if let downloadsURL = FileManager.default.urls(for: .downloadsDirectory, in: .userDomainMask).first {
            do {
                let contents = try FileManager.default.contentsOfDirectory(at: downloadsURL, includingPropertiesForKeys: nil, options: [])
                downloadsContent = contents
            } catch {
                print("Error fetching Downloads contents: \(error.localizedDescription)")
            }
        } else {
            print("Downloads Folder not found")
        }
    }
    
    func openFiles() {
        if let url = URL(string: "shareddocuments://") {
            UIApplication.shared.open(url)
        } else {
            print("Unable to open Downloads folder.")
        }
    }

    func openLink(urlString: String) {
        if let url = URL(string: urlString) {
            UIApplication.shared.open(url)
        }
    }
}
