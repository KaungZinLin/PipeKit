//
//  SettingsViewModel.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 18.11.2023.
//

import SwiftUI
import MessageUI
import UIKit

class SettingsViewModel: NSObject, ObservableObject, MFMailComposeViewControllerDelegate {
    @Published var dailyQuotes = ""
   
    func randomizeQuotes() {
        dailyQuotes = quotes.randomElement()!
    }
    
    func openLink(urlString: String) {
        if let url = URL(string: urlString) {
            UIApplication.shared.open(url)
        }
    }
    
    func sendEmail(recipientEmail: String, subject: String, body: String) {
        if MFMailComposeViewController.canSendMail() {
            let mailComposeViewController = MFMailComposeViewController()
            mailComposeViewController.setToRecipients([recipientEmail])
            mailComposeViewController.setSubject(subject)
            mailComposeViewController.setMessageBody(body, isHTML: false)
            UIApplication.shared.windows.first?.rootViewController?.present(mailComposeViewController, animated: true, completion: nil)
        } else {
        }
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
}

