//
//  YouTubeViewModel.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 19.11.2023.
//

import Foundation

class YouTubeViewModel: ObservableObject {
    @Published var videos: [Video] = []

    func fetchTrendingVideos() {
        guard let url = URL(string: "https://www.googleapis.com/youtube/v3/videos?part=snippet&chart=mostPopular&regionCode=US&maxResults=90&key=\(Constants.YOUTUBE_DATA_V3_API_KEY)") else {
            return
        }

        let task = URLSession.shared.dataTask(with: url) { [weak self] (data, response, error) in
            guard let self = self, let data = data else {
                // Handle error or data nil case
                return
            }

            do {
                let decoder = JSONDecoder()
                let response = try decoder.decode(YouTubeResponse.self, from: data)
                DispatchQueue.main.async {
                    self.videos = response.items
                }
            } catch {
                print("Error decoding JSON: \(error)")
                // Handle decoding error
            }
        }
        task.resume()
    }
}
