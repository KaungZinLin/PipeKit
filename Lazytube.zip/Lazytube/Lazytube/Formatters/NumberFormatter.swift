//
//  NumberFormatter.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 19.11.2023.
//

import Foundation

func formatNumber(_ numberString: String) -> String {
    if let number = Int(numberString) {
        let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .decimal
        return numberFormatter.string(from: NSNumber(value: number)) ?? ""
    }
    return numberString
}
