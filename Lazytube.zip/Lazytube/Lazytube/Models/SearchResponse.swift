//
//  SearchResponse.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 22.11.2023.
//

import Foundation

struct SearchResponse: Decodable {
    let items: [YouTubeVideo]
    // You might need to add other properties if present in the API response
    
    enum CodingKeys: String, CodingKey {
        case items
        // Add other keys if needed
    }
}
