//
//  Search.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 22.11.2023.
//

import Foundation

struct YouTubeVideo: Decodable {
    let id: String
    let channelId: String
    let publishedAt: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case snippet
        case channelId
        case publishedAt
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let snippetContainer = try container.nestedContainer(keyedBy: CodingKeys.self, forKey: .snippet)
        
        id = try container.decode(String.self, forKey: .id)
        channelId = try snippetContainer.decode(String.self, forKey: .channelId)
        publishedAt = try snippetContainer.decode(String.self, forKey: .publishedAt)
    }
}
