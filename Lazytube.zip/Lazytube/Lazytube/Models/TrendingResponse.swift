//
//  TrendingResponse.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 20.11.2023.
//

import Foundation

struct YouTubeResponse: Codable {
    let items: [Video]
}
