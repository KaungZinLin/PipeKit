//
//  Video.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 19.11.2023.
//

import Foundation

struct VideoInfo: Codable {
    let items: [Item]
}

struct Item: Codable {
    let snippet: Snippet
    let statistics: Statistics
}

struct Snippet: Codable {
    let title: String
    let description: String
    let channelId: String
    let channelTitle: String
    let publishedAt: String
}

struct Statistics: Codable {
    let viewCount: String
    let likeCount: String
}
