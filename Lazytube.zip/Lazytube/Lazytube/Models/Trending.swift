//
//  Trending.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 20.11.2023.
//

import Foundation

struct Thumbnails: Codable {
    let high: ThumbnailDetails
}

struct ThumbnailDetails: Codable {
    let url: String
    let width: Int
    let height: Int
}

struct Video: Codable {
    let videoId: String
    let title: String
    let uploader: String
    let thumbnails: Thumbnails
    let uploadDate: String
    let channelTitle: String // Adding channel title property

    enum CodingKeys: String, CodingKey {
        case videoId = "id"
        case snippet
    }

    enum SnippetCodingKeys: String, CodingKey { // Including upload date and channel title keys
        case title
        case channelId
        case thumbnails
        case publishedAt // Upload date key
        case channelTitle // Channel title key
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        let snippetContainer = try container.nestedContainer(keyedBy: SnippetCodingKeys.self, forKey: .snippet)

        videoId = try container.decode(String.self, forKey: .videoId)
        title = try snippetContainer.decode(String.self, forKey: .title)
        uploader = try snippetContainer.decode(String.self, forKey: .channelId)
        thumbnails = try snippetContainer.decode(Thumbnails.self, forKey: .thumbnails)
        uploadDate = try snippetContainer.decode(String.self, forKey: .publishedAt)
        channelTitle = try snippetContainer.decode(String.self, forKey: .channelTitle) // Fetching channel title
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        var snippetContainer = container.nestedContainer(keyedBy: SnippetCodingKeys.self, forKey: .snippet)

        try container.encode(videoId, forKey: .videoId)
        try snippetContainer.encode(title, forKey: .title)
        try snippetContainer.encode(uploader, forKey: .channelId)
        try snippetContainer.encode(thumbnails, forKey: .thumbnails)
        try snippetContainer.encode(uploadDate, forKey: .publishedAt)
        try snippetContainer.encode(channelTitle, forKey: .channelTitle) // Encoding channel title
    }
}

