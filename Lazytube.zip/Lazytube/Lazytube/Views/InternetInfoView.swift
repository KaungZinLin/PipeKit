//
//  InternetInfoView.swift
//  Lazyhuman2.0
//
//  Created by Kaung Zin Lin on 04.11.2023.
//

import SwiftUI
import Network



struct InternetInfoView: View {
    @StateObject var viewModel = NetworkInfoViewModel()
    @State var showWebView = false
    @StateObject var networkMonitor = Speedtest()
    
    var body: some View {
        
    
        VStack(alignment: .leading, spacing: 30) {
            
            Form {
                Section("Connection Status") {
                    if viewModel.isActive == true {
                        Text("You're connected to the internet.")
                    } else {
                        Text("You're not connected to the internet.")
                    }
                }
                
                Section("Connection Type") {
                    
                    Text(verbatim: "\(viewModel.connectionType)")
                        
                }
                
                Section("Expensive Network") {
                    if viewModel.isExpensive == true {
                        Text("Using Cellular Data or Personal Hotspot")
                        Text("Carrier fees could be high.")
                            .foregroundColor(.secondary)
                    } else if viewModel.isConstrained == true {
                        Text("Low Data Mode is On")
                        Text("Loading YouTube videos will be slower.")
                            .foregroundColor(.secondary)
                    } else if viewModel.isActive {
                        Text("You're currently using Wi-Fi.")
                    } else {
                        Text("You're not connected to the internet.")
                    }
                }
                
                Section("Internet Speed Test") {
                    Button("Perform an Internet Speed Test") {
                        showWebView.toggle()
                    }
                    .sheet(isPresented: $showWebView) {
                        WebView(url: URL(string: "https://fast.com/")!)
                    }
                    
                    Text("LazyTube is going to use Fast (by Netflix) to perform an internet speed test.")
                        .foregroundColor(.secondary)
                }

            }
            
        }
        .navigationTitle("Network Monitor")
        
    }
    
    
}

#Preview {
    InternetInfoView()
}
