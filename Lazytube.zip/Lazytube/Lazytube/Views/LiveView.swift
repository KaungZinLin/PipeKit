//
//  LiveView.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 28.11.2023.
//

import SwiftUI

struct LiveView: View {
    var body: some View {
        VStack {
            WebView(url: URL(string: String("https://youtube.com/live/")))
                
               
        }
        .navigationTitle("Live")
        
    }
}

#Preview {
    LiveView()
}
