//
//  ContentView.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 17.11.2023.
//

import SwiftUI
import Network
import WhatsNewKit

struct ContentView: View {
    @ObservedObject var networkMonitor = NetworkManager()
    @State private var showNoInternetAlert = false

    var body: some View {
        TabView {
            YouTubeView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
            
            SummarizerView()
                .tabItem {
                    Image(systemName: "book.fill")
                    Text("AI Summarizer")
                }
            
            DownloadsView()
                .tabItem {
                    Image(systemName: "square.and.arrow.down.fill")
                    Text("Downloads")
                }
            
            SettingsView()
                .tabItem {
                    Image(systemName: "gear")
                    Text("Settings")
                }
        }
        .alert(isPresented: $showNoInternetAlert) {
            Alert(
                title: Text("No Internet Connection"),
                message: Text("Please connect to the internet to use this app."),
                dismissButton: .default(Text("OK"))
            )
        }
        .onReceive(networkMonitor.$isInternetConnected) { isConnected in
            if !isConnected {
                showNoInternetAlert = true
            }
        }
    
    }
}


#Preview {
    ContentView()
}
