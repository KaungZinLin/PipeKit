//
//  DownloadsView.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 17.11.2023.
//

import SwiftUI

struct DownloadsView: View {
    @State var showingAlert = false
    @State var showWebView = false
    @StateObject var viewModel = DownloadsViewModel()

    var body: some View {
        NavigationView {
            VStack {
                
                Form {
                    Section("YouTube Video Downloader") {
                        Button("Download Video") {
                            viewModel.openLink(urlString: "https://yt1s.ltd/en178hmz/")
                        }
                        
                        Text("Ads may appear as it is a free website.")
                            .foregroundColor(.red)
                    }
                    
                    Section("Open Downloads Folder") {
                        Button("Open Files") {
                            viewModel.openFiles()
                        }
                    }
                    
                    Section("Notice") {
                        Text("At Lazyhuman, we respect the YouTube's TOS (Terms of Service). And, downloading YouTube videos are illegal. But, we want our users to get a clean experience of YouTube without paying, and, we've decided to use a YouTube Video Downloading Website to allow our users to download YouTube videos.\n\nWe are not responsible if the site breaks down! \n\nAll credits goes to: https://yt1s.ltd/en178hmz/")
                    }
                }
                
                
            }
            .navigationTitle("Downloads")
            .navigationBarItems(
                leading: NavigationLink(destination: InternetInfoView()) {
                    Image(systemName: "antenna.radiowaves.left.and.right")
                }
            )
        }
            
            
    }
    
}

#Preview {
    DownloadsView()
}
