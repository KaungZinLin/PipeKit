//
//  CommentsView.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 22.11.2023.
//

import SwiftUI

struct CommentsView: View {
    @State var videoId = ""
    
    var body: some View {
        VStack {
            WebView(url: URL(string: "https://www.youtube.com/watch?v=\(videoId)"))
        }
        .navigationTitle("Comments")
    }
}

#Preview {
    CommentsView()
}
