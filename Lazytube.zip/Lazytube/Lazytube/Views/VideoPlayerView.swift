//
//  VideoPlayerView.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 22.11.2023.
//

import SwiftUI
import AVKit

struct VideoPlayerView: View {
    var videoURL: URL

    var body: some View {
        VStack {
            VideoPlayer(player: AVPlayer(url: videoURL))
                .frame(height: 300)
                .edgesIgnoringSafeArea(.all)
        }
    }
}
