//
//  SettingsView.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 18.11.2023.
//

import SwiftUI
import StoreKit
import AlertKit
import WhatsNewKit

struct SettingsView: View {
    let version = WhatsNew.Version(
        major: 1,
        minor: 0,
        patch: 0
    )
    @State var toggleNewYouTube = false
    @State var toggleNewSummarizer = false
    @State var outsideTemperature = 0.0
    @State var longitude = 0
    @State var latitude = 0
    @StateObject var viewModel = SettingsViewModel()
    @State
        var whatsNew: WhatsNew? = WhatsNew(
            title: "What's New in PipeKit",
            features: [
                .init(
                    image: .init(
                        systemName: "play.slash",
                        foregroundColor: .red
                    ),
                    title: "YouTube Experience without Ads",
                    subtitle: "Enjoy YouTube without Ads"
                ),
                .init (
                    image: .init(systemName: "pip.fill", foregroundColor: .green),
                    title: "PiP (Picture-in-Picture)",
                    subtitle: "Enjoy PiP without YT Premium"
                ),
                .init (
                    image: .init(systemName: "headphones", foregroundColor: .green),
                    title: "Background Audio Playback",
                    subtitle: "Enjoy B.A.P without YT Premium"
                ),
                .init (
                    image: .init(systemName: "square.and.arrow.down.fill", foregroundColor: .yellow),
                    title: "Download YouTube Videos",
                    subtitle: "Download YT Videos with 1080p Video Quality"
                ),
                .init (
                    image: .init(systemName: "book.fill", foregroundColor: .orange),
                    title: "YT Video Summarizer",
                    subtitle: "An AI Powered YouTube Video Summarizer"
                ),
                
            ]
        )
   
   
    var body: some View {
        
        NavigationView {
            VStack {
                Form {
                    Section("About App") {
                        HStack {
                            
                            Image("AppLogo")
                                .resizable()
                                .scaledToFit()
                                .frame(height: 100)
                                .clipShape(RoundedRectangle(cornerRadius: 25, style: .continuous))
                                
                            
                            Text("PipeKit")
                                .padding()
                                .font(.custom("AmericanTypewriter", size: 30))
                        }
                        
                        Text("Version 1.0 (Stable) // Build 1000")
                            .foregroundColor(.green)
                        
                        Text("🇵🇸 From the River to the Sea, Palestinians should be free.")
                        
                        Button("Donate to LazyTube", systemImage: "heart") {
                            viewModel.openLink(urlString: "https://www.buymeacoffee.com/lazykaung")
                        }
                    }
                    
                    Section("Quote of the Day") {
                        Text(viewModel.dailyQuotes)
                        Button("Refresh", systemImage: "arrow.clockwise") {
                            viewModel.randomizeQuotes()
                        }
                    }
                    
                    Section("Network Connection") {
                        NavigationLink(destination: InternetInfoView()) {
                            Label("Click here to check network connection", systemImage: "antenna.radiowaves.left.and.right")
                                .foregroundColor(.blue)
                        }
                    }

                    
                    if #available(iOS 16, *) {
                        @Environment(\.requestReview) var requestReview
                        
                        Section("Feedback - How is the experience?") {
                            Button("Happy", systemImage: "hand.thumbsup") {
                                
                                requestReview()
                            }
                            .foregroundColor(.green)
                            
                            Button("Confused", systemImage: "questionmark.app") {
                                viewModel.sendEmail(recipientEmail: Constants.DEVELOPER_EMAIL, subject: "LazyTube Experience - Confused", body: "Please tell us why are use confused using LazyTube. Here, you can tell your thoughts and feelings about the app.")
                            }
                            .foregroundColor(.yellow)
                            
                            Button("Not Happy", systemImage: "hand.thumbsdown") {
                                viewModel.sendEmail(recipientEmail: Constants.DEVELOPER_EMAIL, subject: "LazyTube Experience - Not Happy", body: "Please tell us why you aren't happy using LazyTube. Here, you can tell your thoughts and feeling about this app. You can also tell problems and things that needed to be fix in this app.")
                            }
                            .foregroundColor(.red)
                        }
                    } else {
                        Text("Giving Feedback isn't available in iOS 15.")
                    }
                    
                    
                    
                    Section("Other Info") {
                        Text("© 2023 LazyDeveloper - PipeKit. Do Not Distribute!")
                    }
                }
                
               
            }
            .navigationTitle("Settings")
            .onAppear {
                viewModel.randomizeQuotes()
                
            }
            .sheet(
                whatsNew: self.$whatsNew
            )
        }
    }
}

#Preview {
    SettingsView()
}
