//
//  ChannelView.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 21.11.2023.
//

import SwiftUI

struct ChannelView: View {
    @State var channelId = ""
    @State var navigationTitleString = ""
    @State var aboutChannel = "/about"
    @StateObject var viewModel = ChannelViewModel()
    
    var body: some View {
        VStack {
            WebView(url: URL(string: "\(viewModel.urlString + channelId + aboutChannel)"))
        }
        .navigationTitle(navigationTitleString)
    }
}

#Preview {
    ChannelView()
}
