//
//  SplashScreenView.swift
//  Lazyhuman2.0
//
//  Created by Kaung Zin Lin on 28.10.2023.
//

import SwiftUI

struct SplashScreenView: View {
    @State var isActive : Bool = false
    @State private var size = 0.8
    @State private var opacity = 0.5

    var body: some View {
        
        if isActive {
            ContentView()
        } else {
            VStack {
                
                VStack(alignment: .center) {
                    Image("AppLogo")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 200)
                        .cornerRadius(60)
                        .shadow(radius: 30)
                    
                    
                    
                    Text("For health, take short YouTube breaks.")
                        .padding()
                        .font(.headline)
                        .foregroundColor(.white)
        
                    Text("Version 1.0 (Stable) // Build 1000")
                        .padding()
                        .font(.subheadline)
                        .foregroundColor(.white)
                }
                .scaleEffect(size)
                .opacity(opacity)
                .onAppear {
                    withAnimation(.bouncy(duration: 1.5)) {
                        self.size = 0.9
                        self.opacity = 1.00
                    }
                }
            }
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                    withAnimation {
                        self.isActive = true
                    }
                }
            }
            .background(Color(red: 0.31, green: 0.44, blue: 0.61))
            .edgesIgnoringSafeArea(.all)
            .cornerRadius(30)
            .padding()
        }
        
           
    }
        
}

#Preview {
    SplashScreenView()
}
