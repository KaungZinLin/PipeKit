//
//  SearchView.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 22.11.2023.
//

import SwiftUI

struct SearchView: View {
    @StateObject var viewModel = SearchViewModel()
    @State private var searchResults: [SearchResultsVideo] = []
    @State private var selectedVideo: SearchResultsVideo?
    @State var searchQuery = "Rick Astley - Never Gonna Give You Up (Official Music Video)"
    
    var body: some View {
            VStack {
                List(searchResults, id: \.videoId) { video in
                    VStack(alignment: .leading, spacing: 5) {
                        
                        ThumbnailView(urlString: video.thumbnailUrl)
                            .cornerRadius(30)
                        
                        Text(video.title)
                            .fontWeight(.semibold)
                            .lineLimit(2)
                            .minimumScaleFactor(0.5)
                            .fixedSize(horizontal: false, vertical: true)
                        
                        Text(video.channelTitle)
                            .font(.subheadline)
                            .foregroundColor(.blue)
                        
                        NavigationLink("", destination: YTVideoView(videoId: video.videoId))
                               .foregroundColor(.blue)
                        
                    }
                        //.foregroundColor(.blue)) {
                        
                }
            }
            .navigationTitle("Search Results")
            .onAppear {
                SearchManager.searchYouTube(apiKey: Constants.YOUTUBE_DATA_V3_API_KEY, query: searchQuery) { videos in
                    self.searchResults = videos
                }
        }
    }
        
}


#Preview {
    SearchView()
}
