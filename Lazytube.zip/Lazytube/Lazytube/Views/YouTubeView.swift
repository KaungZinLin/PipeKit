//
//  YouTubeView.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 17.11.2023.
//

import SwiftUI

struct YouTubeView: View {
    @State var searchQuery = ""
    @ObservedObject var viewModel = YouTubeViewModel()
    @State var videoId = "dQw4w9WgXcQ"
    @State var searchQueryiOS15 = ""

    var body: some View {
        NavigationView {
            
            VStack {
                Form {
                    if #available(iOS 16, *) {
                        
                    } else {
                        Section("For iOS 15 Users Only") {
                            TextField("Search Keyword...", text: $searchQueryiOS15)
                                .textSelection(.enabled)
                                .autocorrectionDisabled()
                            
                            NavigationLink("Search for '\(searchQueryiOS15)'", destination: SearchView(searchQuery: searchQueryiOS15))
                                .foregroundColor(.blue)
                        }
                    }
                    
                    Section("Play Video From a YouTube Video ID") {
                        TextField("Insert a Valid YouTube Video ID", text: $videoId)
                            .textSelection(.enabled)
                            .foregroundColor(.green)
                        
                        NavigationLink("Load and Play Video", destination: YTVideoView(videoId: videoId))
                            .foregroundColor(.blue)
                    }
                    
                    Section("Trending") {
                        List(viewModel.videos, id: \.videoId) { video in
                            VStack(alignment: .leading, spacing: 5) {

                                ThumbnailView(urlString: video.thumbnails.high.url)
                                    .aspectRatio(contentMode: .fill)
                                    .cornerRadius(30)
                                
                                Text("\(video.title)")
                                    .fontWeight(.semibold)
                                    .lineLimit(2)
                                    .minimumScaleFactor(0.5)
                                    .fixedSize(horizontal:false, vertical: true)
                                    
                                
                                Text("\(video.channelTitle)")
                                    .font(.subheadline)
                                    .foregroundColor(.blue)
                                
                                Text("\(video.uploadDate)")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                                
                                NavigationLink("", destination: YTVideoView(videoId: video.videoId))
                                    .foregroundColor(.blue)
                            }
                        }
                    }
                    
                    Section("Live") {
                        NavigationLink("Live on YouTube", destination: LiveView())
                            .foregroundColor(.blue)
                    }
                    
                    Section("End of Trending") {
                        Text("You're all caught up! Go outside and enjoy the nature ;)")
                            .foregroundColor(.green)
                    }
                }
                
            }
            
            .navigationTitle("Home")
            .navigationBarItems(leading: NavigationLink(destination: InternetInfoView()) {
                Image(systemName: "antenna.radiowaves.left.and.right")
            })
            .navigationBarItems(trailing: Button(action: {
                viewModel.fetchTrendingVideos()
            }) {
                Image(systemName: "arrow.clockwise")
            }
            
            )
            .searchable(text: $searchQuery, placement: .automatic) {
                NavigationLink("Search for '\(searchQuery)'", destination: SearchView(searchQuery: searchQuery))
                    .foregroundColor(.blue)
            }
            .onAppear {
                viewModel.fetchTrendingVideos()
            }
            
        }
    }
}

#Preview {
    YouTubeView()
}
