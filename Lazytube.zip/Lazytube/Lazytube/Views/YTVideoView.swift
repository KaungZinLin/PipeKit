//
//  YTVideoView.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 19.11.2023.
//

import SwiftUI
import YouTubePlayerKit
import AVFoundation

var globalVideoId = ""
var globalViewModel = YTVideoViewModel()

struct YTVideoView: View {
    @State private var videoInfo: Item?
    @State var videoId = "dQw4w9WgXcQ"
    @StateObject var viewModel = YTVideoViewModel()
    @State private var selectedPlayer: SideOfSelectedViews = .statistics
    
    var body: some View {
        VStack {
            YouTubePlayerView(
                YouTubePlayer(source: .video(id: videoId))
            )
            .cornerRadius(40)
            .padding()
            
            Picker("Choose a Music Streaming Service", selection: $selectedPlayer) {
                
                ForEach(SideOfSelectedViews.allCases, id: \.self) {
                    Text($0.rawValue)
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding()
            

            SelectedView(selectedSide: selectedPlayer, selectedVideoId: videoId)

        }
        .navigationTitle("YouTube Video")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            YTVideoViewModel.shared.fetchVideoInfo(videoId: videoId) { item in
                if let item = item {
                    self.videoInfo = item
                }
            }
        }
    }
}

enum SideOfSelectedViews: String, CaseIterable {
    case statistics = "Statistics"
    case description = "Description"
    case comments = "Comments"
    case other = "Other"
    // case soundcloud = "Soundcloud"
}

struct SelectedView: View {
    
    var selectedSide: SideOfSelectedViews
    var selectedVideoId = ""
    
    var body: some View {
        
        switch selectedSide {

        case .statistics:
            StatisticsView(videoId: selectedVideoId)
        case .description:
            DescriptionView(videoId: selectedVideoId)
        case .comments:
            SelectedCommentsView(videoId: selectedVideoId)
        case .other:
            OtherView(videoId: selectedVideoId)
        
        }
    }
}

struct StatisticsView: View {
    @State private var videoInfo: Item?
    var videoId = ""
    
    var body: some View {
        
            VStack {
                Form {
                    Section("Video Title") {
                        Text(videoInfo?.snippet.title ?? "N/A")
                    }
                    
                    Section("Video Statistics") {
                        HStack {
                            Text(Image(systemName: "hand.thumbsup.fill")) +
                            
                            Text(" \(formatNumber(videoInfo?.statistics.likeCount ?? "N/A"))")
                            
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                            
                            Text(Image(systemName: "eye.fill"))
                            
                            Text(formatNumber(videoInfo?.statistics.viewCount ?? "N/A"))
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                        }
                        
                        Label {
                            Text(videoInfo?.snippet.publishedAt ?? "N/A")
                        }
                    icon: {
                        Image(systemName: "calendar.circle.fill")
                            .foregroundColor(.secondary)
                    }
                        
                    }
                }
            }
        
        .onAppear {
            YTVideoViewModel.shared.fetchVideoInfo(videoId: videoId) { item in
                if let item = item {
                    self.videoInfo = item
                }
            }
        }
    }
}

struct DescriptionView: View {
    @State private var videoInfo: Item?
    var videoId = ""
    
    var body: some View {
        
            VStack {
                Form {
                    Section("Video Description") {
                        Text(videoInfo?.snippet.description ?? "N/A")
                        Button("Speak Out (Beta)") {
                            let utterance = AVSpeechUtterance(string: "\(videoInfo?.snippet.description)")
                            utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
                            utterance.rate = 0.5
                            
                            let synthesizer = AVSpeechSynthesizer()
                            synthesizer.speak(utterance)
                        }
                    }
                }
            }
        
        .onAppear {
            YTVideoViewModel.shared.fetchVideoInfo(videoId: videoId) { item in
                if let item = item {
                    self.videoInfo = item
                }
            }
        }
    }
}

struct SelectedCommentsView: View {
    
    var videoId = ""
    @State private var videoInfo: Item?
    
    var body: some View {
        VStack {
            WebView(url: URL(string: "https://www.youtube.com/watch?v=\(videoId)"))
        }
    }
}

struct OtherView: View {
    @State private var videoInfo: Item?
    var videoId = ""
    
    var body: some View {
        
            VStack {
                Form {
                    Section("Share Video Link") {
                        if #available(iOS 16, *) {
                            ShareLink(item: "\(globalViewModel.urlString + videoId)", preview: SharePreview("Share Video Link"))
                        } else {
                            Text("Sharing Video Link is not available in iOS 15.")
                                .foregroundColor(.red)
                            
                            Text("Touch and hold to copy video link.")
                                .foregroundColor(.secondary)
                            Text("\(globalViewModel.urlString + videoId)")
                                .foregroundColor(.green)
                                .textSelection(.enabled)
                            
                        }
                    }
                    
                    Section("Share Video ID") {
                        if #available(iOS 16, *) {
                            ShareLink(item: "\(videoId)", preview: SharePreview("Share Video Link"))
                        } else {
                            Text("Sharing Video ID is not available in iOS 15.")
                                .foregroundColor(.red)
                            
                            Text("Touch and hold to copy video link.")
                                .foregroundColor(.secondary)
                            Text("\(globalVideoId)")
                                .foregroundColor(.green)
                                .textSelection(.enabled)
                            
                        }
                    }
                    
                    Section {
                        Text("Having Network Problems?")
                        NavigationLink("Click here to check network connection", destination: InternetInfoView())
                            .foregroundColor(.blue)
                    }
                }
            }
        
    }
}



#Preview {
    YTVideoView()
}
