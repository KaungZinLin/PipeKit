//
//  SummarizerView.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 17.11.2023.
//

import SwiftUI

struct SummarizerView: View {
    var body: some View {
        NavigationView {
            WebView(url: URL(string: "https://www.summarize.tech/"))
                .navigationTitle("Summarizer")
                .navigationBarItems(
                    leading: NavigationLink(destination: InternetInfoView()) {
                        Image(systemName: "antenna.radiowaves.left.and.right")
                    }
                )
        }
        
    }
}

#Preview {
    SummarizerView()
}
