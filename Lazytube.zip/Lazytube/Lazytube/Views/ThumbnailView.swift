//
//  ThumbnailView.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 20.11.2023.
//

import SwiftUI

struct ThumbnailView: View {
    let urlString: String
    @State var data: Data?
    
    var body: some View {
        if let data = data, let uiImage = UIImage(data: data) {
            Image(uiImage: uiImage)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .cornerRadius(30)
                .frame(width: 320, height: 180)
                .background(Color.gray)
        } else {
            Image(systemName: "video.fill")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: 320, height: 180)
                .cornerRadius(30)
                .background(Color.gray)
                .onAppear {
                    fetchData()
                }
        }
    }
    
    private func fetchData() {
        guard let url = URL(string: urlString) else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { data,
            _, _ in
            self.data = data
        }
        
        task.resume()
    }
}

#Preview {
    ThumbnailView(urlString: "")
}

