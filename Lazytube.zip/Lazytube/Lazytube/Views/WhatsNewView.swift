//
//  WhatsNewView.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 23.11.2023.
//

import SwiftUI
import WhatsNewKit

struct WhatsNewView: View {
   
    
    var body: some View {
        VStack {
            
        }
        
    }
}

#Preview {
    WhatsNewView()
}
