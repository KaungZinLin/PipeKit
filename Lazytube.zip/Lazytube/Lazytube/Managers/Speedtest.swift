//
//  Speedtest.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 06.12.2023.
//

import Foundation
import Network

class Speedtest: ObservableObject {
    let monitor = NWPathMonitor()
    let queue = DispatchQueue(label: "Monitor")
    
    @Published var isConnected: Bool = false
    @Published var downloadSpeed: Double = 0.0
    @Published var uploadSpeed: Double = 0.0
    
    init() {
        monitor.pathUpdateHandler = { path in
            self.isConnected = path.status == .satisfied
            if self.isConnected {
                self.getSpeed()
            }
        }
        monitor.start(queue: queue)
    }
    
    func getSpeed() {
        let url = URL(string: "https://speedtest.net")!
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else { return }
            let start = CFAbsoluteTimeGetCurrent()
            URLSession.shared.downloadTask(with: url) { _, _, error in
                guard error == nil else { return }
                let end = CFAbsoluteTimeGetCurrent()
                let elapsed = end - start
                let speed = 1024 * 1024 / elapsed
                DispatchQueue.main.async {
                    self.downloadSpeed = Double(speed)
                }
            }.resume()
            let startUpload = CFAbsoluteTimeGetCurrent()
            URLSession.shared.uploadTask(with: URLRequest(url: url), from: data) { _, _, error in
                guard error == nil else { return }
                let endUpload = CFAbsoluteTimeGetCurrent()
                let elapsedUpload = endUpload - startUpload
                let speedUpload = 1024 * 1024 / elapsedUpload
                DispatchQueue.main.async {
                    self.uploadSpeed = Double(speedUpload)
                }
            }.resume()
        }
        task.resume()
    }
}
