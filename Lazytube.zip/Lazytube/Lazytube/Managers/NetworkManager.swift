//
//  NetworkManager.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 21.11.2023.
//

import Foundation
import Network

class NetworkManager: ObservableObject {
    let monitor = NWPathMonitor()
    let queue = DispatchQueue.global(qos: .background)
    @Published var isInternetConnected = true
    
    init() {
        monitor.pathUpdateHandler = { [weak self] path in
            self?.isInternetConnected = path.status == .satisfied
        }
        
        monitor.start(queue: queue)
    }
}
