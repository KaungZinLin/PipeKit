//
//  LocationManager.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 18.11.2023.
//

import Foundation
import CoreLocation

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    private var locationManager = CLLocationManager()
    @Published var userLocation: CLLocation?
    @Published var userLatitude: Double = 0.0
    @Published var userLongitude: Double = 0.0

    override init() {
        super.init()
        self.locationManager.delegate = self
    }

    func requestLocation() {
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        print("Latitude: \(self.userLatitude)")
        print("Longitude: \(self.userLongitude)")
        
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            userLocation = location
            // Update @Published properties for latitude and longitude
            DispatchQueue.main.async {
                self.userLatitude = location.coordinate.latitude
                self.userLongitude = location.coordinate.longitude
                
            }
        }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Location manager failed with error: \(error.localizedDescription)")
    }
}
