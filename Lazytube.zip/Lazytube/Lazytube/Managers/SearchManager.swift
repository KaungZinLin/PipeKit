//
//  SearchManager.swift
//  Lazytube
//
//  Created by Kaung Zin Lin on 22.11.2023.
//

import Foundation
import SwiftUI

class SearchManager {
    static func searchYouTube(apiKey: String, query: String, completion: @escaping ([SearchResultsVideo]) -> Void) {
        // let searchUrl = "https://www.googleapis.com/youtube/v3/search?key=\(apiKey)&q=\(query)&part=snippet&type=video"
        
        let maxResults = 100

        let searchUrl = "https://www.googleapis.com/youtube/v3/search?key=\(apiKey)&q=\(query)&part=snippet&type=video&maxResults=\(maxResults)"

        if let url = URL(string: searchUrl) {
            URLSession.shared.dataTask(with: url) { data, response, error in
                if let data = data {
                    do {
                        if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                            if let items = json["items"] as? [[String: Any]] {
                                var searchResults: [SearchResultsVideo] = []
                                for item in items {
                                    if let videoId = item["id"] as? [String: String], let videoIdString = videoId["videoId"] {
                                        fetchVideoDetails(apiKey: apiKey, videoId: videoIdString) { videoDetails in
                                            if let videoDetails = videoDetails {
                                                searchResults.append(videoDetails)
                                                if searchResults.count == items.count {
                                                    DispatchQueue.main.async {
                                                        completion(searchResults)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch {
                        print("Error parsing JSON: \(error)")
                    }
                } else if let error = error {
                    print("Error performing request: \(error)")
                }
            }.resume()
        } else {
            print("Invalid URL")
        }
    }

    static func fetchVideoDetails(apiKey: String, videoId: String, completion: @escaping (SearchResultsVideo?) -> Void) {
        let detailsUrl = "https://www.googleapis.com/youtube/v3/videos?key=\(apiKey)&id=\(videoId)&part=snippet"

        if let url = URL(string: detailsUrl) {
            URLSession.shared.dataTask(with: url) { data, response, error in
                if let data = data {
                    do {
                        if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                            if let items = json["items"] as? [[String: Any]], let item = items.first {
                                if let snippet = item["snippet"] as? [String: Any],
                                   let title = snippet["title"] as? String,
                                   let channelTitle = snippet["channelTitle"] as? String,
                                   let publishedAt = snippet["publishedAt"] as? String,
                                   let description = snippet["description"] as? String,
                                   let channelId = snippet["channelId"] as? String,
                                   let thumbnails = snippet["thumbnails"] as? [String: Any],
                                   let mediumThumbnail = thumbnails["medium"] as? [String: Any],
                                   let thumbnailUrl = mediumThumbnail["url"] as? String {
                                    completion(SearchResultsVideo(videoId: videoId, title: title, channelTitle: channelTitle, publishedAt: publishedAt, description: description, thumbnailUrl: thumbnailUrl))
                                }
                            }
                        }
                    } catch {
                        print("Error parsing JSON: \(error)")
                    }
                } else if let error = error {
                    print("Error performing request: \(error)")
                }
            }.resume()
        } else {
            print("Invalid URL")
            completion(nil)
        }
    }
}

struct SearchResultsVideo: Identifiable {
    var id = UUID()
    var videoId: String
    var title: String
    var channelTitle: String
    var publishedAt: String
    var description: String
    var thumbnailUrl: String // Added thumbnail URL
}
